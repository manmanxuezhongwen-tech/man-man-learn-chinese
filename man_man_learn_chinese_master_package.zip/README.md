# Man Man Learn Chinese 慢慢学中文 — HSK 1 Launch

Static web app (HTML/CSS/JavaScript), prepared for free hosting with GitHub Pages.

## Publish with GitHub Pages
1. Sign in or create a GitHub account.
2. Create a **Public** repository named `man-man-learn-chinese`.
3. Upload `index.html` from this folder to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for the Pages deployment. The site URL will look like:
   `https://YOUR-USERNAME.github.io/man-man-learn-chinese/`

Replace `YOUR-USERNAME` with your GitHub username. This is the permanent master URL; later updates are made by replacing/editing `index.html` in the same repository.

## Notes
- The current version is a prototype and has a curated beginner HSK 1 vocabulary module. It is not yet a fully verified official complete vocabulary syllabus.
- Speech uses the device/browser text-to-speech voice. Availability and pronunciation quality depend on the user's device.
- Progress is saved locally in the user's browser/device, not in a cloud account.
